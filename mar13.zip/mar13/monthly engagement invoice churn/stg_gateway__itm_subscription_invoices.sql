{{ config(
    materialized='incremental',
    incremental_strategy='insert_overwrite',
    partition_by=['invoice_created_month'],
    file_format='parquet',
    tags=["exposed", "subscription_invoices","fee_health", "gateway", "staging_flow_a"]
) }}


SELECT /*+ COALESCE(1) */
    stash_user_uuid,
    raw_invoice_id,
    invoice_id,
    fee_collection_system,
    was_successfully_collected,
    successful_collection_method,
    attempted_manual_rescue,
    is_partial_charge,
    latest_collection_attempt_outcome,
    latest_collection_attempt_payment_status,
    invoice_status,
    raw_invoice_status,
    number_of_collection_attempts,
    fee_collected_amount,
    initial_fee_amount,
    discount_name,
    latest_failure_reason_cash,
    latest_failure_reason_external_bank,
    latest_failure_reason_plastic,
    latest_failure_reason_position,
    latest_failure_reason_stash_bank,
    latest_general_failure_reason_cash,
    latest_general_failure_reason_external_bank,
    latest_general_failure_reason_plastic,
    latest_general_failure_reason_position,
    latest_general_failure_reason_stash_bank,
    latest_collection_method,
    latest_fee_amount,
    invoice_month,
    invoice_year,
    billing_frequency,
    billing_period_start,
    billing_period_end,
    invoice_created_date,
    subscription_tier,
    raw_subscription_tier,
    fee_charge_date,
    initial_collection_attempted_at,
    latest_collection_attempted_at,
    latest_collection_attempt_outcome_at,
    collection_attempt_list,
    TRUNC(fee_charge_date, 'month') AS fee_charge_month,
    TRUNC(invoice_created_date, 'month') AS invoice_created_month

FROM
    {{ source('gateway','itm_subscription_invoices') }}

WHERE
    1 = 1


    {% if target.name == 'dev' %}

    AND TRUNC(invoice_created_date, 'month') > CURRENT_DATE - INTERVAL 5 MONTH

    {% endif %}

    {% if is_incremental() %}

        AND TRUNC(invoice_created_date, 'month') > CURRENT_DATE - INTERVAL 3 MONTH

    {% endif %}
