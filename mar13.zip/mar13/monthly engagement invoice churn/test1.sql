


-- TO DO TONIGHT THURSDAY 3/7:
-- SPIN UP ALT
-- FIND A BETTER EXAMPLE OF A COMPLICATED USER CASE
-- that looks like

-- 2024-03-01	churned
-- 2024-02-01	retained
-- 2024-01-01	retained  returned
-- 2023-12-01	new       Transfer canceled with reason(s): Fee


-- RUN THIS MODEL (it pulls directly from source now)
-- AND THEN IN SQL RUNNER RUN THIS:

-- select stash_user_id
-- from mart_dev.test1
-- where stash_user_id % 10 = 0
-- group by 1
-- having COUNT(DISTINCT lead_invoice_failure_reason_external_bank) >= 2

-- ALSO TRY running test2 without the order by in the window, and see if it picks up that null row





-- Did the customer pay their subscription invoice?
-- There can be multiple invoices/month, so grab the last of each month
-- Annual invoices are prorated (proration stops at churn)

WITH invoices AS (
    SELECT
        *,
        TRUNC(fee_charge_date, 'month') AS fee_charge_month,
        TRUNC(invoice_created_date, 'month') AS invoice_created_month
    FROM {{ source('gateway','itm_subscription_invoices') }}
),


events AS ( -- Get all invoices
    SELECT

        users.stash_user_id,
        invoices.fee_charge_month,
        MAX_BY(invoices.invoice_id, invoices.fee_charge_date) AS event_id,
        MAX_BY(invoices.subscription_tier, invoices.fee_charge_date) AS last_invoice_tier_of_month,
        MAX_BY(invoices.fee_charge_date, invoices.fee_charge_date) AS event_from,
        MAX_BY(invoices.billing_period_end, invoices.fee_charge_date) AS event_to, -- Churn the month after the billing period ends
        MAX_BY(invoices.billing_frequency, invoices.fee_charge_date) AS invoice_billing_frequency,
        MAX_BY(invoices.latest_failure_reason_external_bank, invoices.fee_charge_date) AS invoice_failure_reason_detail_external_bank,
        MAX_BY(invoices.latest_failure_reason_stash_bank, invoices.fee_charge_date) AS invoice_failure_reason_detail_stash_bank,
        MAX_BY(invoices.latest_general_failure_reason_external_bank, invoices.fee_charge_date) AS invoice_failure_reason_external_bank,
        MAX_BY(invoices.latest_general_failure_reason_cash, invoices.fee_charge_date) AS invoice_failure_reason_cash,
        MAX_BY(invoices.latest_general_failure_reason_plastic, invoices.fee_charge_date) AS invoice_failure_reason_plastic,
        MAX_BY(invoices.latest_general_failure_reason_position, invoices.fee_charge_date) AS invoice_failure_reason_position,
        MAX_BY(invoices.latest_general_failure_reason_stash_bank, invoices.fee_charge_date) AS invoice_failure_reason_stash_bank,
        MAX_BY(invoices.latest_collection_attempt_outcome, invoices.fee_charge_date) AS latest_collection_attempt_outcome,
        MAX_BY(invoices.fee_collected_amount, invoices.fee_charge_date) AS fee_collected_amount,
        MAX_BY(invoices.invoice_status, invoices.fee_charge_date) AS invoice_status

    FROM invoices
    LEFT JOIN
        mart.stg_source_pg_main__users AS users
        ON
            users.stash_user_uuid = invoices.stash_user_uuid

    WHERE

        1=1


        -- AND (
        --     users.stash_user_id % 100000 = 0
        --     OR users.stash_user_id IN (24570560, 24824921, 24735691, -- Interesting revenue+close cases.
        --         10650920, 1529551) -- For testing failure reasons
        -- )


    GROUP BY
        1, 2
),

failure_reasons AS ( -- Get the following month's invoice failure for churned rows (we'll filter for churn in exposed tables)
    SELECT

        event_id,
        LEAD(invoice_failure_reason_external_bank) OVER (PARTITION BY stash_user_id ORDER BY fee_charge_month ASC) AS lead_invoice_failure_reason_external_bank,
        LEAD(invoice_failure_reason_cash) OVER (PARTITION BY stash_user_id ORDER BY fee_charge_month ASC) AS lead_invoice_failure_reason_cash,
        LEAD(invoice_failure_reason_plastic) OVER (PARTITION BY stash_user_id ORDER BY fee_charge_month ASC) AS lead_invoice_failure_reason_plastic,
        LEAD(invoice_failure_reason_position) OVER (PARTITION BY stash_user_id ORDER BY fee_charge_month ASC) AS lead_invoice_failure_reason_position,
        LEAD(invoice_failure_reason_stash_bank) OVER (PARTITION BY stash_user_id ORDER BY fee_charge_month ASC) AS lead_invoice_failure_reason_stash_bank,
        LEAD(invoice_failure_reason_detail_external_bank) OVER (PARTITION BY stash_user_id ORDER BY fee_charge_month ASC) AS lead_invoice_failure_reason_detail_external_bank,
        LEAD(invoice_failure_reason_detail_stash_bank) OVER (PARTITION BY stash_user_id ORDER BY fee_charge_month ASC) AS lead_invoice_failure_reason_detail_stash_bank,
        LEAD(invoice_status) OVER (PARTITION BY stash_user_id ORDER BY fee_charge_month ASC) AS lead_invoice_status

    FROM events
)

-- Filter for successfully collected invoices
SELECT

    events.stash_user_id,
    events.event_id,
    events.last_invoice_tier_of_month,

    CASE
        WHEN
            events.invoice_billing_frequency = 'Monthly' -- Does not prorate monthly invoices b/c event_from = event_to
        THEN events.event_from
        WHEN
            events.invoice_billing_frequency = 'Annual' -- Prorates annual invoices b/c event_from != event_to
        THEN events.event_to
    END AS event_to,

    events.event_from,
    events.invoice_billing_frequency,

    CASE
        WHEN
            failure_reasons.lead_invoice_status = 'returned'
        THEN 'returned'
        ELSE failure_reasons.lead_invoice_failure_reason_external_bank
    END AS lead_invoice_failure_reason_external_bank,

    failure_reasons.lead_invoice_failure_reason_cash,
    failure_reasons.lead_invoice_failure_reason_plastic,
    failure_reasons.lead_invoice_failure_reason_position,
    failure_reasons.lead_invoice_failure_reason_stash_bank,
    failure_reasons.lead_invoice_failure_reason_detail_external_bank,
    failure_reasons.lead_invoice_failure_reason_detail_stash_bank

FROM events
LEFT JOIN failure_reasons
    ON events.event_id = failure_reasons.event_id

WHERE

    events.latest_collection_attempt_outcome = 'success'
    AND events.fee_collected_amount > 0