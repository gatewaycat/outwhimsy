select

    stash_user_id,
    event_month,
    invoice_engagement,
    lead_invoice_failure_reason_external_bank,

    case when invoice_engagement = 'churned' then
    lag(lead_invoice_failure_reason_external_bank) over w
    end
    as test_lag,

    case when invoice_engagement = 'churned' then
    max(lead_invoice_failure_reason_external_bank) over w
    end
    as test_max,

    case when invoice_engagement = 'churned' then
    max_by(lead_invoice_failure_reason_external_bank, event_month) over w
    end
    as test_maxby,

    case when invoice_engagement = 'churned' then
    max_by(
        lead_invoice_failure_reason_external_bank,
        case
            when lead_invoice_failure_reason_external_bank is not null
            then event_month
        end
    ) over w
    end
    as test_maxby_case,

    case when invoice_engagement = 'churned' then
    last(lead_invoice_failure_reason_external_bank) ignore nulls over w
    end
    as test_last_ignorenulls

from mart_dev.test2 -- mart.nltx_monthly_engagement__itm_invoice

where
    event_month >= '2023-11-01'
    and stash_user_id in (24860072, 24796456, 24760016, 24753235)

order by 1 desc, 2 desc

window w as (partition by stash_user_id order by event_month)
