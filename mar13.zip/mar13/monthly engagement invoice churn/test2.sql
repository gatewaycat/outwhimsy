SELECT

    *,

    NULLIF(
        -- Last tier of previous month (1)
        LAG(last_invoice_tier_of_month) OVER w,
        -- Last tier of current month (2)
        last_invoice_tier_of_month
    )
    || '_to_'
    || last_invoice_tier_of_month
    AS invoice_tier_change, -- Null if (1) is null, (2) is null, or (1)=(2).
    CAST(event_from AS DATE) AS fee_charge_date,
    MAX(CAST(event_from AS DATE)) OVER w AS last_fee_charge_date_thus_far,
    MAX_BY(invoice_billing_frequency, event_month) OVER w AS last_invoice_billing_frequency_thus_far,

    -- For 'churned' rows, get the failure reason by method
    CASE
        WHEN
            invoice_engagement = 'churned'
        THEN MAX_BY(
            lead_invoice_failure_reason_external_bank,
            CASE
                WHEN lead_invoice_failure_reason_external_bank IS NOT NULL
                THEN event_month
            END
        ) OVER w
    END AS invoice_failure_reason_external_bank,

    CASE
        WHEN
            invoice_engagement = 'churned'
        THEN MAX_BY(lead_invoice_failure_reason_cash, event_month) OVER w
    END AS invoice_failure_reason_cash,

    CASE
        WHEN
            invoice_engagement = 'churned'
        THEN MAX_BY(lead_invoice_failure_reason_plastic, event_month) OVER w
    END AS invoice_failure_reason_plastic,

    CASE
        WHEN
            invoice_engagement = 'churned'
        THEN MAX_BY(lead_invoice_failure_reason_position, event_month) OVER w
    END AS invoice_failure_reason_position,

    CASE
        WHEN
            invoice_engagement = 'churned'
        THEN MAX_BY(lead_invoice_failure_reason_stash_bank, event_month) OVER w
    END AS invoice_failure_reason_stash_bank,

    CASE
        WHEN
            invoice_engagement = 'churned'
        THEN MAX_BY(lead_invoice_failure_reason_detail_external_bank, event_month) OVER w
    END AS invoice_failure_reason_detail_external_bank,

    CASE
        WHEN
            invoice_engagement = 'churned'
        THEN MAX_BY(lead_invoice_failure_reason_detail_stash_bank, event_month) OVER w
    END AS invoice_failure_reason_detail_stash_bank


FROM (




-- Tag `exclude_from_circle` since
-- dbt_utils.get_filtered_columns_in_relation
-- will fail circle, which has no database connection.






-- Grab the event name and source model.
-- from the filename of the model calling this macro.




----------------------------------------------------------------------
-- EVENT NAME is invoice.
-- SOURCE MODEL is nltx_monthly_engagement__evt_invoice.
----------------------------------------------------------------------




-- Grab the column names from the source model.






-- Set event_from and event_to used in the rest of this macro
-- according to what type of date/time columns the sources uses.
-- This macro allows for point-events (event_at),
-- or alternately, interval-events (event_from and event_to).









-- Set has_churn_reason to .






-- Grab the remaining column names, which will be LISTAGGed
-- and "passed through" in the sense that they have
-- no bearing on the engagement compuatation.






-- To summarize, the source model MUST have
--
--     STASH_USER_ID
--
-- and either
--
--     EVENT_AT
--
-- xor
--
--     EVENT_DATE
--
-- xor
--
--     EVENT_FROM and EVENT_TO.
--
-- The source model MAY have
--
--     PRIMARY_KEY, EVENT_ID, EVENT_MONTH,
--     EVENT_QUARTER, EVENT_YEAR
--
-- which will be ignored.
--
-- The source model MAY have
--
--     CHURN_REASON
--
-- which will aggregated in a special way.
--
-- The source model can also have other columns,
-- which will be passed through and LISTAGGed
-- in a standard way.




WITH events AS (
    SELECT

        stash_user_id,


            last_invoice_tier_of_month,

            event_from,

            invoice_billing_frequency,

            lead_invoice_failure_reason_external_bank,

            lead_invoice_failure_reason_cash,

            lead_invoice_failure_reason_plastic,

            lead_invoice_failure_reason_position,

            lead_invoice_failure_reason_stash_bank,

            lead_invoice_failure_reason_detail_external_bank,

            lead_invoice_failure_reason_detail_stash_bank,




        MIN(
            TRUNC(event_from, 'month')
        ) OVER (
            PARTITION BY stash_user_id
        ) AS first_event_month,

        TRUNC(event_from, 'month') AS event_from_month,
        TRUNC(event_to, 'month') AS event_to_month

    FROM mart_dev.test1
    WHERE event_from IS NOT NULL
),




months AS (
    SELECT EXPLODE(SEQUENCE(DATE '2015-01', CURRENT_DATE, INTERVAL 1 MONTH)) AS reporting_month
),




events_months AS (
    SELECT

        events.stash_user_id,


            events.last_invoice_tier_of_month,

            events.event_from,

            events.invoice_billing_frequency,

            events.lead_invoice_failure_reason_external_bank,

            events.lead_invoice_failure_reason_cash,

            events.lead_invoice_failure_reason_plastic,

            events.lead_invoice_failure_reason_position,

            events.lead_invoice_failure_reason_stash_bank,

            events.lead_invoice_failure_reason_detail_external_bank,

            events.lead_invoice_failure_reason_detail_stash_bank,




        (
            months.reporting_month
            BETWEEN events.event_from_month
            AND COALESCE(events.event_to_month, months.reporting_month)
        )
        AS has_event,

        (
            months.reporting_month
            = events.event_to_month + INTERVAL 1 MONTH
        )
        AS has_event_end,

        events.first_event_month,
        months.reporting_month

    FROM events
    CROSS JOIN months
    WHERE events.first_event_month <= months.reporting_month -- (**) Delete reporting months before user's first event.
),




users_months AS (
    SELECT

        stash_user_id,

        MAX(has_event) AS has_event,
        LAG(MAX(has_event)) OVER (PARTITION BY stash_user_id ORDER BY reporting_month) AS had_event_month_before,

        COUNT(CASE WHEN has_event THEN TRUE END) AS event_count,


            NULLIF(
                CONCAT_WS(' and ', SORT_ARRAY(COLLECT_SET(CASE WHEN has_event THEN last_invoice_tier_of_month END))),
                ''
            ) AS last_invoice_tier_of_month,

            NULLIF(
                CONCAT_WS(' and ', SORT_ARRAY(COLLECT_SET(CASE WHEN has_event THEN event_from END))),
                ''
            ) AS event_from,

            NULLIF(
                CONCAT_WS(' and ', SORT_ARRAY(COLLECT_SET(CASE WHEN has_event THEN invoice_billing_frequency END))),
                ''
            ) AS invoice_billing_frequency,

            NULLIF(
                CONCAT_WS(' and ', SORT_ARRAY(COLLECT_SET(CASE WHEN has_event THEN lead_invoice_failure_reason_external_bank END))),
                ''
            ) AS lead_invoice_failure_reason_external_bank,

            NULLIF(
                CONCAT_WS(' and ', SORT_ARRAY(COLLECT_SET(CASE WHEN has_event THEN lead_invoice_failure_reason_cash END))),
                ''
            ) AS lead_invoice_failure_reason_cash,

            NULLIF(
                CONCAT_WS(' and ', SORT_ARRAY(COLLECT_SET(CASE WHEN has_event THEN lead_invoice_failure_reason_plastic END))),
                ''
            ) AS lead_invoice_failure_reason_plastic,

            NULLIF(
                CONCAT_WS(' and ', SORT_ARRAY(COLLECT_SET(CASE WHEN has_event THEN lead_invoice_failure_reason_position END))),
                ''
            ) AS lead_invoice_failure_reason_position,

            NULLIF(
                CONCAT_WS(' and ', SORT_ARRAY(COLLECT_SET(CASE WHEN has_event THEN lead_invoice_failure_reason_stash_bank END))),
                ''
            ) AS lead_invoice_failure_reason_stash_bank,

            NULLIF(
                CONCAT_WS(' and ', SORT_ARRAY(COLLECT_SET(CASE WHEN has_event THEN lead_invoice_failure_reason_detail_external_bank END))),
                ''
            ) AS lead_invoice_failure_reason_detail_external_bank,

            NULLIF(
                CONCAT_WS(' and ', SORT_ARRAY(COLLECT_SET(CASE WHEN has_event THEN lead_invoice_failure_reason_detail_stash_bank END))),
                ''
            ) AS lead_invoice_failure_reason_detail_stash_bank,




        FIRST(first_event_month) AS first_event_month, -- All the same, so take any value.

        MAX(
            CASE WHEN MAX(has_event) THEN reporting_month END
        ) OVER (
            PARTITION BY stash_user_id
            ORDER BY reporting_month -- To make it incremental by month (non-backfilling).
        ) AS last_event_month_thus_far,

        reporting_month

    FROM events_months
    GROUP BY stash_user_id, reporting_month
),




users_engagement AS (
    SELECT

        stash_user_id || '-' || SUBSTRING(reporting_month, 1, 7) AS monthly_engagement_id,
        stash_user_id,

        CASE
            WHEN reporting_month < first_event_month THEN NULL -- Already filtered out at (**) above.
            WHEN reporting_month = first_event_month THEN 'new'
            WHEN has_event AND had_event_month_before THEN 'retained'
            WHEN has_event AND NOT had_event_month_before THEN 'reactivated'
            WHEN NOT has_event AND had_event_month_before THEN 'churned'
            WHEN NOT has_event AND NOT had_event_month_before THEN 'still_churned'
        END AS invoice_engagement,

        event_count AS invoice_count,


            last_invoice_tier_of_month,

            event_from,

            invoice_billing_frequency,

            lead_invoice_failure_reason_external_bank,

            lead_invoice_failure_reason_cash,

            lead_invoice_failure_reason_plastic,

            lead_invoice_failure_reason_position,

            lead_invoice_failure_reason_stash_bank,

            lead_invoice_failure_reason_detail_external_bank,

            lead_invoice_failure_reason_detail_stash_bank,


        -- If a user "churns and reactivates" in the same month,
        -- we consider that "retained," and so hide the churn_reason.


        first_event_month AS first_invoice_month,

        -- In looker, use last_event_month_thus_far and event_month together
        -- to cut off the still_churned older than a date
        -- churn in cumulative churn charts like DSA-3407,
        -- which uses the filter,
        --     WHERE
        --         event_month >= 2022-06-01 (
        --         AND (
        --             last_event_month_thus_far >= 2022-06-01
        --             OR last_event_month_thus_far IS NULL
        --         )
        last_event_month_thus_far AS last_invoice_month_thus_far,

        reporting_month AS event_month

    FROM users_months
)




SELECT
    *,

    NULLIF(
        -- Engagement of previous month (1)
        LAG(invoice_engagement) OVER (PARTITION BY stash_user_id ORDER BY event_month),
        -- Engagement of current month (2)
        invoice_engagement
    )
    || '_to_'
    || invoice_engagement
    AS invoice_engagement_change -- Null if (1) is null, (2) is null, or (1)=(2).


FROM users_engagement



)
WINDOW w AS (PARTITION BY stash_user_id ORDER BY event_month)