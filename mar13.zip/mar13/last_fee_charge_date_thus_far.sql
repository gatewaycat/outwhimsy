select
    stash_user_id,
    fee_charge_date,
    max(fee_charge_date) over (
        partition by stash_user_id
        order by event_month
    )
    as last_fee_charge_date_thus_far,
    event_month
from mart_dev.nltx_monthly_engagement__itm_invoice
