try changing the dev filter to be on subs.process_date. that source table integrated_users.user_expected_contribution_new_subscriber_leading is partitioned on process_date.

the 



{% set sql_statement %}
    SELECT MAX(process_date)
    FROM {{ source('integrated_users', 'user_expected_contribution_new_subscriber_leading') }}
{% endset %}
{% set max_process_date = dbt_utils.get_single_value(sql_statement) %}


WITH subs AS (
    SELECT
        user_id AS stash_user_id,
        new_subscriber_leading_probability AS subscriber_probability,
        new_subscriber_leading_contribution AS subscriber_contribution,
        MIN_BY(new_subscriber_leading_subscribed_at, process_date) AS subscribed_at
    FROM {{ source('integrated_users', 'user_expected_contribution_new_subscriber_leading') }}
    WHERE
        process_date = {{ max_process_date }}
        AND new_subscriber_leading_subscribed_at IS NOT NULL
)



    SELECT
        subs.user_id,
        users.stash_user_uuid,
        DATE(subs.new_subscriber_leading_subscribed_at) AS subscribed_at,
        attribution.campaign,
        subs.new_subscriber_leading_probability AS subscriber_probability,
        subs.new_subscriber_leading_contribution AS subscriber_contribution
    FROM
        {{ source(
            'integrated_users',
            'user_expected_contribution_new_subscriber_leading'
        ) }} AS subs
    JOIN {{ ref('stg_source_pg_main__users') }}  AS users ON subs.user_id=users.stash_user_id
    LEFT JOIN
        {{ ref('mart_attribution') }} AS attribution
        ON subs.user_id = attribution.stash_user_id
    WHERE
        subs.process_date
        = (
            SELECT MAX(process_date)
            FROM
                {{ source(
                    'integrated_users',
                    'user_expected_contribution_new_subscriber_leading'
                ) }}
        )
        AND
        subs.new_subscriber_leading_subscribed_at IS NOT NULL
    {% if target.name == 'dev' %}
        AND DATE(subs.new_subscriber_leading_subscribed_at) > CURRENT_DATE - INTERVAL 1 DAYS
        {% endif %}
