WITH dupe_accounts AS
(SELECT
        users.uuid AS old_uuid,
        split_part(body, 'UUID: ',2) AS new_uuid,
        aasm_state AS new_account_status
        FROM source_pg_main.users
        RIGHT JOIN source_pg_main.active_admin_comments ON users.id = active_admin_comments.resource_id
        WHERE resource_type = 'User'
        AND active_admin_comments.body LIKE '%[AUTO] DUPLICATE ACCOUNT%'),

old_account_status AS
(SELECT
        old_uuid,
        users.aasm_state
 FROM dupe_accounts
 LEFT JOIN source_pg_main.users ON dupe_accounts.old_uuid = users.uuid
),
  
ssn_attempts AS
(SELECT  new_uuid,
        count(distinct dupe_accounts.old_uuid) AS duplicate_users,
        count(distinct CASE WHEN aasm_state IN ('inactive') THEN dupe_accounts.old_uuid ELSE null END) AS duplicate_inactive_users
FROM dupe_accounts
LEFT JOIN old_account_status ON dupe_accounts.old_uuid = old_account_status.old_uuid
GROUP BY 1),

wisdom_test_membership AS (SELECT source, test, variant, user_id, first_event_at, last_event_at, device_id
      FROM wisdom.test_membership
      WHERE process_date = (
        SELECT MAX(process_date)
        FROM wisdom.test_membership
        where process_date > CURRENT_DATE - Interval '3 days')
      ),
      
duplicate_accounts AS
(SELECT 
        d.new_uuid,
        d.new_account_status,
        sa.duplicate_users,
        sa.duplicate_inactive_users
FROM dupe_accounts d
LEFT JOIN ssn_attempts sa ON d.new_uuid = sa.new_uuid)

SELECT 
      wisdom_test_membership.variant,
      COUNT(DISTINCT wisdom_test_membership.user_id ) AS users_in_test,
      SUM(duplicate_accounts.duplicate_users) AS dupes,
      SUM(duplicate_accounts.duplicate_inactive_users) AS inactive_dupes,
      COALESCE(CAST( ( SUM(DISTINCT (CAST(FLOOR(COALESCE( duplicate_accounts.duplicate_users  ,0)*(1000000*1.0)) AS DECIMAL(38,0))) + CAST(STRTOL(LEFT(MD5(CAST( duplicate_accounts.new_uuid   AS VARCHAR)),15),16) AS DECIMAL(38,0))* 1.0e8 + CAST(STRTOL(RIGHT(MD5(CAST( duplicate_accounts.new_uuid   AS VARCHAR)),15),16) AS DECIMAL(38,0)) ) - SUM(DISTINCT CAST(STRTOL(LEFT(MD5(CAST( duplicate_accounts.new_uuid   AS VARCHAR)),15),16) AS DECIMAL(38,0))* 1.0e8 + CAST(STRTOL(RIGHT(MD5(CAST( duplicate_accounts.new_uuid   AS VARCHAR)),15),16) AS DECIMAL(38,0))) )  AS DOUBLE PRECISION) / CAST((1000000*1.0) AS DOUBLE PRECISION), 0) AS "duplicate_accounts.total_duplicate_users",
    COALESCE(CAST( ( SUM(DISTINCT (CAST(FLOOR(COALESCE( duplicate_accounts.duplicate_inactive_users  ,0)*(1000000*1.0)) AS DECIMAL(38,0))) + CAST(STRTOL(LEFT(MD5(CAST( duplicate_accounts.new_uuid   AS VARCHAR)),15),16) AS DECIMAL(38,0))* 1.0e8 + CAST(STRTOL(RIGHT(MD5(CAST( duplicate_accounts.new_uuid   AS VARCHAR)),15),16) AS DECIMAL(38,0)) ) - SUM(DISTINCT CAST(STRTOL(LEFT(MD5(CAST( duplicate_accounts.new_uuid   AS VARCHAR)),15),16) AS DECIMAL(38,0))* 1.0e8 + CAST(STRTOL(RIGHT(MD5(CAST( duplicate_accounts.new_uuid   AS VARCHAR)),15),16) AS DECIMAL(38,0))) )  AS DOUBLE PRECISION) / CAST((1000000*1.0) AS DOUBLE PRECISION), 0) AS "duplicate_accounts.total_duplicate_inactive_users"
FROM source_pg_main.users
LEFT JOIN duplicate_accounts ON duplicate_accounts.new_uuid = users.uuid
LEFT JOIN wisdom_test_membership ON wisdom_test_membership.user_id = users.id
WHERE (( wisdom_test_membership.test  ) ILIKE  '2022-03-17-skip-aasm-state-test')
GROUP BY 1
