/* Runtime: 30s */

select /*+ COALESCE(1) */
	coalesce(	offer_cash.amount,
		offer_stock_rewards.amount,
		offer_waive_subscriptions.total_free_months,
		offer_cash_matches.max_amount
		) as amount,

	offer_subscription_discounts.subscription_discount_type_name	as discount,
	promotions.id	as romotion_id,
	promotions.name	as romotion_name,
	promotion_offers.offer_type	as romotion_type,
	promotion_categories.name	as romotion_category

from	{{source('bounty','promotions')}} left join
	{{source('bounty','promotion_categories')}}	on promotions.promotion_category_id = promotion_categories.id left join
	{{source('bounty','promotion_offers')}}	on promotions.id = promotion_offers.promotion_id left join
	{{source('bounty','offer_cash')}}	on promotion_offers.offer_id = offer_cash.id left join
	{{source('bounty','offer_waive_subscriptions')}}	on promotion_offers.offer_id = offer_waive_subscriptions.id left join
	{{source('bounty','offer_stock_rewards')}}	on promotion_offers.offer_id = offer_stock_rewards.id left join
	{{source('bounty','offer_cash_matches')}}	on promotion_offers.offer_id = offer_cash_matches.id left join
	{{source('bounty','offer_subscription_discounts')}}	on promotion_offers.offer_id = offer_subscription_discounts.id

where	/* These promotions have no information attached */
	promotion_offers.offer_type is not null and
	/* These promotions are massively duplicated */
	promotions.id not in (	'a0ac8365-b8e5-48b3-894a-30031182f504',
		'42b01bbe-f1a6-4aee-9609-b689d15ad516',
		'7652b49c-fa4d-42ae-bd52-e3fc7141102a',
		'38775fee-b0f5-4e8e-b527-c70d30feb4b4',
		'fabbe029-4229-4d75-af11-527cc4614aa8',
		'e8486b26-b332-45ec-9654-10618d011d4f',
		'd09c6774-c590-4184-b8dd-524989a06739',
		'e995a10b-d1b1-4e5f-a02e-bd4796106465',
		'78d4b903-60e5-4c4a-bc54-9094e6c028f4',
		'93923a96-b59b-481e-9337-cbd2e09e4a1e',
		'93ad25a7-e935-45b5-881c-0ce51bef8d66',
		'ee03f3f9-2631-46eb-8cc8-9cf5debad8eb',
		'b53b073e-37e1-44ba-bb30-a48ddfd3ba77',
		'f73acba1-270b-49df-9910-1897113cc65d',
		'883b8fa0-c74d-4df7-b42e-09103c9d4ed0',
		'455ae49a-0ff2-45c2-b953-b41ab34f7acc',
		'384db441-df36-4137-9e75-7945f8e381c0',
		'6d549170-4807-4fd0-ab22-69ef66585326',
		'1e451fbf-83ed-472b-9928-b68a6f846ac6',
		'b63b0b36-938c-464e-a978-749377541b3e',
		'3ac6cbd1-cf33-4ebf-bdf9-1e97f66480e3',
		'2947fff3-50d8-4acd-8697-e157d825764f',
		'0037f6fd-a452-4ace-83ab-a15d0f7f3f0c',
		'3a02fd9d-06dd-4ea6-8b4a-e24839f72e18',
		'8dc6feec-c037-4d24-8e0f-2cb7915ead5f',
		'96aaf41c-901d-4977-9575-ed3a134b914c'
		)
