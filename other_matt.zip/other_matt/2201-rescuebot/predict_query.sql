WITH user_links AS (
SELECT      u.id AS user_id,
            CASE WHEN MAX(b.user_id) IS NOT NULL OR MAX(fs.user_id) IS NOT NULL THEN true ELSE false END AS ever_linked
FROM        source_pg_main.users u
LEFT JOIN   source_pg_main.bank_accounts b
  ON        u.id = b.user_id
  AND       b.approval_method IN ('MICRO_DEPOSIT', 'PLAID', 'QUOVO')
  AND       b.aasm_state IN ('approved', 'canceled')
LEFT JOIN   source_pg_main.funding_sources fs
  ON        fs.user_id = u.id
  AND       fs.provider_type IN ('PLASTIC', 'PLASTIC_CREDIT', 'PLASTIC_PREPAID')
GROUP BY    1
),

user_intent AS (
SELECT      user_answer.user_id,
            CONCAT(
              MAX(CASE WHEN answer.key IN ('financial_advice_and_education', 'learn_about_finance') THEN 'A' ELSE '' END),
              MAX(CASE WHEN answer.key IN ('build_better_budgeting_habits', 'save_and_spend_smarter') THEN 'B' ELSE '' END),
              MAX(CASE WHEN answer.key IN ('avoid_banking_fees_and_minimums') THEN 'F' ELSE '' END),
              MAX(CASE WHEN answer.key IN ('save_for_goals_and_emergencies', 'save_for_the_unexpected') THEN 'G' ELSE '' END),
              MAX(CASE WHEN answer.key IN ('invest_and_build_wealth', 'build_an_investment_portfolio', 'buy_stock','earn_stocks') THEN 'I' ELSE '' END),
              MAX(CASE WHEN answer.key IN ('invest_for_my_kids') THEN 'K' ELSE '' END),
              MAX(CASE WHEN answer.key IN ('get_paid_earlier') THEN 'P' ELSE '' END),
              MAX(CASE WHEN answer.key IN ('save_for_retirement', 'prepare_for_retirement') THEN 'R' ELSE '' END)
              ) AS intent
FROM        source_pg_main.user_guidance_question_answers user_answer
JOIN        source_pg_main.guidance_question_answers answer USING (guidance_question_id)
JOIN        source_pg_main.guidance_questions question
 ON         question.id = user_answer.guidance_question_id
WHERE       user_answer.guidance_question_answer_id = answer.id AND
            user_answer.guidance_question_id = question.id AND
            question.key IN ('how_do_you_want_to_use_stash',' what_brings_you_here')
GROUP BY    1
),

fund AS (
SELECT      user_id,
            true AS has_funded
FROM        integrated_users.universal_transfers
WHERE       source='external'
GROUP BY    1
),

last_lock_event AS (
SELECT      user_id,
            event_type AS last_lock_event
FROM        (
			SELECT    user_id,
					  event_type,
					  ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY applied_at DESC) AS lock_row
			FROM	  source_pg_main.lock_events
			)
WHERE lock_row = 1
),

last_email_open AS (
SELECT      stash_uuid,
            MAX(from_unixtime(time)) AS last_email_open_at
FROM        source_braze.events
WHERE       event = 'users.messages.email.Open' AND
            process_date >= date_sub('{{run_date}}', {{pre_subscriber_start}})
GROUP BY    stash_uuid
)

SELECT      u.id AS stash_user_id,
            u.uuid AS stash_user_uuid,
            CAST(datediff('{{run_date}}', up.date_of_birth) / 365.25 AS INT) AS age,
            datediff('{{run_date}}', u.created_at) AS days_since_user_create,
            COALESCE(up.home_state, up.mailing_state) AS home_state,
            ia.annual_income_range AS income,
            ia.children_under_18,
            ia.employment_status,
            ia.investing_experience,
            ia.risk_tolerance,
            ia.marital_status,
            ia.have_a_retirement_account AS external_retirement_account,
            ui.intent
FROM        source_pg_main.users u
JOIN        source_pg_main.user_profiles up
 ON         u.id = up.user_id
JOIN        source_pg_main.investor_applications ia
 ON         u.id = ia.user_id
LEFT JOIN   user_links ul
 ON         u.id = ul.user_id
LEFT JOIN   fund
 ON         u.id = fund.user_id
LEFT JOIN   last_lock_event
 ON         u.id = last_lock_event.user_id
LEFT JOIN   user_intent ui
 ON         u.id = ui.user_id
LEFT JOIN   last_email_open le
 ON         u.uuid = le.stash_uuid
WHERE       ( COALESCE(NOT ul.ever_linked, true) OR COALESCE(NOT fund.has_funded, true) ) AND COALESCE(last_lock_event.last_lock_event='UNLOCK', true) AND
            datediff(CAST('{{run_date}}' AS DATE), u.created_at) > {{pre_subscriber_end}} AND
            (
             datediff(u.created_at, le.last_email_open_at) < {{pre_subscriber_start}} OR
             (le.last_email_open_at IS NULL AND datediff(CAST('{{run_date}}' AS DATE), u.created_at) < {{pre_subscriber_start}})
            )
