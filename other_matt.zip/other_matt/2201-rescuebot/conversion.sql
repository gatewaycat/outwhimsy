with ever_linked as (
select   user_id as stash_user_id
from     source_pg_main.bank_accounts full outer join
         source_pg_main.funding_sources using (user_id)
where    funding_sources.provider_type in ('PLASTIC', 'PLASTIC_CREDIT', 'PLASTIC_PREPAID') or
         bank_accounts.approval_method in ('MICRO_DEPOSIT', 'PLAID', 'QUOVO') and
         bank_accounts.aasm_state IN ('approved', 'canceled')
group by 1),



has_funded as (
select   user_id as stash_user_id
from     integrated_users.universal_transfers
where    source='external'
group by 1),



last_lock_event as (
select  user_id as stash_user_id,
        event_type AS last_lock_event
from   (select  user_id,
                event_type,
                ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY applied_at DESC) AS lock_row
        from    source_pg_main.lock_events)
where   lock_row = 1),

is_locked as (
select  stash_user_id
from    last_lock_event
where   last_lock_event!='UNLOCK'),



has_recent_email_open AS (
select   stash_uuid as stash_user_uuid
from     source_braze.events
where    event = 'users.messages.email.Open' and
         process_date >= date_sub('{{run_date}}', 37)
group by stash_user_uuid)


select   stash_user_id
from    (select id as stash_user_id, uuid as stash_user_uuid from source_pg_main.users)
             as users left join
         ever_linked           using (stash_user_id) left join 
         fund                  using (stash_user_id) left join
         is_locked             using (stash_user_id) left join
         has_recent_email_open using (stash_user_uuid)
where   (          ever_linked.stash_user_id is null or 
                          fund.stash_user_id is null) and
                     is_locked.stash_user_id is null and
        (has_recent_email_open.stash_user_id is not null or
         datediff(CAST('2022-01-24' AS DATE), u.created_at) < 365)
