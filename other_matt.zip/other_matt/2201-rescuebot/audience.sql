user_links AS (

SELECT      u.id AS user_id,
            CASE WHEN MAX(b.user_id) IS NOT NULL 
                      OR MAX(fs.user_id) IS NOT NULL 
                      THEN true 
                 ELSE false
            END AS ever_linked

FROM        source_pg_main.users u

LEFT JOIN   source_pg_main.bank_accounts b
  ON        u.id = b.user_id
  AND       b.approval_method IN ('MICRO_DEPOSIT', 'PLAID', 'QUOVO')
  AND       b.aasm_state IN ('approved', 'canceled')

LEFT JOIN   source_pg_main.funding_sources fs
  ON        fs.user_id = u.id
  AND       fs.provider_type IN ('PLASTIC', 'PLASTIC_CREDIT', 'PLASTIC_PREPAID')

GROUP BY    1

),

cost AS (
SELECT    u.uuid,
          CASE WHEN a.e_signature_agreed_at IS NULL THEN 0 
               WHEN a.e_signature_agreed_at IS NOT NULL 
                    AND a.e_signature_agreed_at < date_sub(CAST('{{run_date}}' AS DATE), 1) 
                    AND COALESCE(NOT user_links.ever_linked, true) THEN 0
               ELSE -1 END AS cost
FROM      source_pg_main.accounts a
JOIN      source_pg_main.users u
 ON       a.user_id = u.id
LEFT JOIN user_links
 ON       a.user_id = user_links.user_id
WHERE     a.account_type = 'PERSONAL_BROKERAGE'
)

SELECT    cost.cost
FROM      source_braze.events b
 ON       cb_sent.uuid = b.stash_uuid
WHERE     b.event = 'users.messages.email.Delivery' AND 
          campaign_id IN {{messages}} AND
          b.process_date BETWEEN date_sub(CAST('{{run_date}}' AS DATE), 1) AND current_timestamp