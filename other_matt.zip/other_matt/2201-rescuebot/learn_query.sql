WITH user_intent AS (
SELECT      user_answer.user_id,
            CONCAT(
              MAX(CASE WHEN answer.key IN ('financial_advice_and_education', 'learn_about_finance') THEN 'A' ELSE '' END),
              MAX(CASE WHEN answer.key IN ('build_better_budgeting_habits', 'save_and_spend_smarter') THEN 'B' ELSE '' END),
              MAX(CASE WHEN answer.key IN ('avoid_banking_fees_and_minimums') THEN 'F' ELSE '' END),
              MAX(CASE WHEN answer.key IN ('save_for_goals_and_emergencies', 'save_for_the_unexpected') THEN 'G' ELSE '' END),
              MAX(CASE WHEN answer.key IN ('invest_and_build_wealth', 'build_an_investment_portfolio', 'buy_stock','earn_stocks') THEN 'I' ELSE '' END),
              MAX(CASE WHEN answer.key IN ('invest_for_my_kids') THEN 'K' ELSE '' END),
              MAX(CASE WHEN answer.key IN ('get_paid_earlier') THEN 'P' ELSE '' END),
              MAX(CASE WHEN answer.key IN ('save_for_retirement', 'prepare_for_retirement') THEN 'R' ELSE '' END)
              ) AS intent 
FROM        source_pg_main.user_guidance_question_answers user_answer
JOIN        source_pg_main.guidance_question_answers answer USING (guidance_question_id)
JOIN        source_pg_main.guidance_questions question 
 ON         question.id = user_answer.guidance_question_id
WHERE       user_answer.guidance_question_answer_id = answer.id AND
            user_answer.guidance_question_id = question.id AND
            question.key IN ('how_do_you_want_to_use_stash',' what_brings_you_here')
GROUP BY    1
),

user_links AS (
SELECT      u.id AS user_id,
            CASE WHEN MAX(b.user_id) IS NOT NULL OR MAX(fs.user_id) IS NOT NULL THEN true ELSE false END AS ever_linked
FROM        source_pg_main.users u
LEFT JOIN   source_pg_main.bank_accounts b
  ON        u.id = b.user_id
  AND       b.approval_method IN ('MICRO_DEPOSIT', 'PLAID', 'QUOVO')
  AND       b.aasm_state IN ('approved', 'canceled')
LEFT JOIN   source_pg_main.funding_sources fs
  ON        fs.user_id = u.id
  AND       fs.provider_type IN ('PLASTIC', 'PLASTIC_CREDIT', 'PLASTIC_PREPAID')
GROUP BY    1
),

features AS (
SELECT      u.id AS stash_user_id,
            u.uuid AS stash_user_uuid,
            CAST(datediff(CAST('{{run_date}}' AS DATE), up.date_of_birth) / 365.25 AS INT) AS age,
            datediff(CAST('{{run_date}}' AS DATE), u.created_at) AS days_since_user_create,
            COALESCE(up.home_state, up.mailing_state) AS home_state,
            ia.annual_income_range AS income,
            ia.children_under_18,
            ia.employment_status,
            ia.investing_experience,
            ia.risk_tolerance,
            ia.marital_status,
            ia.have_a_retirement_account AS external_retirement_account,
            ui.intent
FROM        source_pg_main.users u
JOIN        source_pg_main.user_profiles up 
 ON         u.id = up.user_id
JOIN        source_pg_main.investor_applications ia 
 ON         u.id = ia.user_id 
LEFT JOIN   user_intent ui
 ON         u.id = ui.user_id
),

cost AS (
SELECT    u.uuid,
          CASE WHEN a.e_signature_agreed_at IS NULL THEN 0 
               WHEN a.e_signature_agreed_at IS NOT NULL AND a.e_signature_agreed_at < date_sub(CAST('{{run_date}}' AS DATE), 1) AND COALESCE(NOT user_links.ever_linked, true) THEN 0
               ELSE -1 END AS cost
FROM      source_pg_main.accounts a
JOIN      source_pg_main.users u
 ON       a.user_id = u.id
LEFT JOIN user_links
 ON       a.user_id = user_links.user_id
WHERE     a.account_type = 'PERSONAL_BROKERAGE'
)

SELECT    features.*,
          cost.cost,
          cb_sent.chosen_message,
          cb_sent.probability_message,
          cb_sent.chosen_time,
          cb_sent.probability_time
FROM      integrated_users.rescuebot_emails_sent cb_sent
JOIN      features
 ON       features.stash_user_uuid = cb_sent.uuid
JOIN      cost
 ON       cost.uuid = cb_sent.uuid
JOIN      source_braze.events b
 ON       cb_sent.uuid = b.stash_uuid
WHERE     b.event = 'users.messages.email.Delivery' AND 
          campaign_id IN {{messages}} AND
          b.process_date BETWEEN date_sub(CAST('{{run_date}}' AS DATE), 1) AND current_timestamp
