with party_size as (
select
  party_id,
  count(distinct participant_id) as party_size
from source_pg_stockparty.party_claims
group by 1
),

party as (
select
  participants.uuid as stash_user_uuid,
  party_claims.created_at as redeemed_at,
  1.0*parties.dollar_amount/party_size as amount
from
  source_pg_stockparty.participants left join
  source_pg_stockparty.party_claims on participants.id = party_claims.participant_id left join
  source_pg_stockparty.parties on party_claims.party_id = parties.id left join
  party_size on parties.id = party_size.party_id
where
  amount > 0 and
  redeemed_at between '2021-01-01' and '2022-01-01'
),

stockback as (
select
  user_uuid as stash_user_uuid,
  created_at as redeemed_at,
  reward_amount as amount
from source_pg_main.stock_rewards
where
  amount > 0 and
  redeemed_at between '2021-01-01' and '2022-01-01'
),

-- bounty as (
-- select
--   stash_user_uuid,
--   redeemed_at,
--   amount as redeemed_amount
-- from
--   mart.promotion left join
--   mart.users using (stash_user_id)
-- where
--   amount > 0 and
--   redeemed_at between '2021-01-01' and '2022-01-01'
-- ),

bounty as (
Select
	users.stash_user_uuid,
	por0.created_at As redeemed_at,
	coalesce(oc0.amount,osr0.amount) as redeemed_amount
From source_pg_bounty.promotion_eligibilities pe0
Left Join source_pg_bounty.promotions p0 On p0.id = pe0.promotion_id
Left Join source_pg_bounty.promotion_categories pc0 On pc0.id = p0.promotion_category_id
Left Join source_pg_bounty.promotion_offer_redemptions por0 On por0.promotion_eligibility_id = pe0.id
Left Join source_pg_bounty.promotion_offers po0 On po0.promotion_id = p0.id
Left Join source_pg_bounty.offer_cash oc0 On oc0.id = po0.offer_id And po0.offer_type = 'OfferCash'
Left Join source_pg_bounty.offer_waive_subscriptions ows0 On ows0.id = po0.offer_id And po0.offer_type = 'OfferWaiveSubscription'
Left Join source_pg_bounty.offer_stock_rewards osr0 On osr0.id = po0.offer_id And po0.offer_type = 'OfferStockReward'
Left Join source_pg_bounty.offer_cash_matches ocm0 On ocm0.id = po0.offer_id And po0.offer_type = 'OfferCashMatch'
Left Join source_pg_bounty.offer_subscription_discounts osd0 On osd0.id = po0.offer_id And po0.offer_type = 'OfferSubscriptionDiscount'
Left Join source_pg_bounty.sharing_codes sc0 On sc0.promotion_id = p0.id
left join mart.users on pe0.user_id = users.stash_user_id
where
  redeemed_amount > 0 and
  redeemed_at between '2021-01-01' and '2022-01-01'
),

unions as (
select stash_user_uuid, amount from party union all
select stash_user_uuid, amount from stockback union all
select stash_user_uuid, redeemed_amount as amount from bounty
),

target_users as (
select
  stash_user_uuid,
  round(sum(amount),2) as total_amount
from unions
group by 1
having total_amount >= 600
)

select
  users.stash_user_id,
  target_users.stash_user_uuid,
  target_users.total_amount,
  user_profiles.home_street_address, 
  user_profiles.home_city, 
  user_profiles.home_state, 
  user_profiles.home_postal_code, 
  user_profiles.home_country, 
  user_profiles.encrypted_social_security_number, 
  user_profiles.hashed_social_security_number
from
  target_users left join
  mart.users using (stash_user_uuid) left join
  source_pg_main.user_profiles on users.stash_user_id = user_profiles.user_id
