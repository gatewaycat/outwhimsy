with onboarding_depth as (

select

    users.id as stash_user_id,
    min(users.created_at) as create_,
    min(subscription_actions.created_at) as tier_,
    min(funding_sources.created_at) as plastic_,
    min(user_esignatures.esigned_at) as advisory_,
    min(users.e_signature_agreed_at) as accounts_,
    min(account_state_transitions.created_at) as complete_,
    min(user_pmt_linked.linked_bank_funding_date) as bank_,
    min(invoices.charge_date) as attempt_,
    min(invoices.collection_completed_at) as collection_,
    min(transfers.first_deposit_completed_at) as fund_,
    min(invest.personal_brokerage_first_buy_at) as invest_,
    case
        when datediff(minute,create_,complete_) <= 15 and
            datediff(minute,create_,bank_) <= 15 and
            datediff(minute,create_,fund_) <= 15 and
            datediff(minute,create_,invest_) <= 15 then '9 Invest'
        when datediff(minute,create_,complete_) <= 15 and
            datediff(minute,create_,bank_) <= 15 and
            datediff(minute,create_,fund_) <= 15 then '8 Fund'
        when datediff(minute,create_,bank_) <= 15 and
            datediff(minute,create_,complete_) <= 15 then '7 Bank Link'
        when datediff(minute,create_,complete_) <= 15 then '6 Complete'
        when datediff(minute,create_,accounts_) <= 15 then '5 Accounts eSig'
        when datediff(minute,create_,advisory_) <= 15 then '4 Advisory eSig'
        when datediff(minute,create_,plastic_) <= 15 then '3 Plastic Link'
        when datediff(minute,create_,tier_) <= 15 then '2 Tier Select'
        else '1 User Create' end as onboarding_depth_minute_15

from

    source_pg_main.users left join
    source_subscriptions.users as subscription_users using(uuid) left join
    source_subscriptions.user_esignatures on            subscription_users.id = user_esignatures.user_id left join
    source_subscriptions.subscriptions on               subscription_users.id = subscriptions.user_id left join
    source_subscriptions.invoices on                    subscriptions.id = invoices.subscription_id left join
    source_subscriptions.subscription_actions on        subscriptions.id = subscription_actions.subscription_id and
                                                        subscription_actions.new_plan_id is not null and
                                                        subscription_actions.action = 'create' left join
    integrated_users.user_pmt_linked on                 users.id = user_pmt_linked.user_id left join
    source_pg_main.funding_sources on                   users.id = funding_sources.user_id and
                                                        funding_sources.provider_type like '%PLASTIC%' left join
    source_pg_main.accounts on                          users.id = accounts.user_id left join
    source_pg_main.account_state_transitions on         accounts.id = account_state_transitions.account_id and
                                                        account_state_transitions.to_aasm_state = 'complete' left join
    mart.invest on                                      users.id = invest.stash_user_id left join
    mart.transfers on                                   users.id = transfers.stash_user_id

group by 1
),


mixpanel as (

select
    uuid as stash_user_uuid,
    
    timestamp 'epoch' + interval '1 second' * time as event_at

    (event in ('LogIn','LogIn') and 
        screenname like '%log-in%') as fe_login_impression,

    (event = 'LogIn') as fe_login_success,

    case when mp_lib != 'ruby' and
        event not in ('LogIn','LogIn') and
        screenname not like '%log-in%' then users.id end as fe_non_login_event,

    case when mp_lib != 'ruby' and
        event not in ('LogIn','LogIn') and
        screenname not like '%log-in%' and (
        event like '%Registration%' or 
        screenname like '%sign-up%') then users.id end as fe_reg_event

from
    mart.users inner join
    source_mixpanel.events on users.stash_user_uuid = mixpanel.uuid

where
    mixpanel.process_date between '2021-11-01' and '2021-11-09' and
    users.user_created_at between '2021-11-01' and '2021-12-01'
    
)


select
    stash_user_id,
    
    onboarding_depth_minute_15,

    (event in ('LogIn','LogIn') and 
        screenname like '%log-in%') as fe_login_impression,

    (event = 'LogIn') as fe_login_success,

    case when mp_lib != 'ruby' and
        event not in ('LogIn','LogIn') and
        screenname not like '%log-in%' then users.id end as fe_non_login_event,

    case when mp_lib != 'ruby' and
        event not in ('LogIn','LogIn') and
        screenname not like '%log-in%' and (
        event like '%Registration%' or 
        screenname like '%sign-up%') then users.id end as fe_reg_event

from
    mart.users left join
    onboarding_depth using(stash_user_id) left join
    source_mixpanel.events as mixpanel on users.stash_user_uuid = mixpanel.uuid

where
    mixpanel.process_date between '2021-11-01' and '2021-11-09' and
    users.user_created_at between '2021-11-01' and '2021-12-01'

group by 1
order by 1