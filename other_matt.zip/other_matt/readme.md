# Copy/Paste

✓✗_  
⬅ ⮕ ➡ ⬆ ⬇ ⬉ ⬈ ⬊ ⬋ ← → ↑ ↓ ⟵ ⟶  
⬆ ↑ ↥ ↰ ↱ ⇅ ⇞ ⇧ ⇪ ⦽ ⬆ ꜛ ⬆️  https://www.amp-what.com/unicode/search/up%20arrow

# To Do List

1. Lakecat
   1. https://app.slack.com/client/T048HP6GU/C02N7CRPLE5 https://datahub-prod.stsh.io/
   1. https://github.com/StashInvest/roundups/blob/edge/src/main/python/roundups/roundups.py
   1. https://www.google.com/search?q=datahub+api&oq=datahub+api+&aqs=chrome..69i57j0i22i30l3j0i10i22i30j0i22i30j0i10i22i30j69i60.4740j1j4&sourceid=chrome&ie=UTF-8 https://graphql.org/learn/queries/
   1. https://graphql.org/learn/introspection/


# Cheatsheet

1. `%load_ext sql`
   `%sql postgresql://matt_suderland:1RwJGrW2nyWjL39s80YkoQuTk1QG6KsJUbzG6cMzidvj4QnpDwg4tZc8uAIduvKk@de-prod-00.c7ewlyppqts9.us-east-1.redshift.amazonaws.com:5439/prod`
   `%config SqlMagic.autopandas=True`
1. `from IPython.core.interactiveshell import InteractiveShell`
   `InteractiveShell.ast_node_interactivity = "all"`
1. Deploy Datamart to Prod
   `zip -rX data-mart.zip data-mart`
   `aws --profile default s3 cp data-mart.zip s3://stash-de-artifacts-prod/data_science/data-mart/latest/app.zip`
   `{"run_add_on" : "--models my_model_name", "test_add_on" : "--models my_model_name"}`
```
echo "1" | stash-okta --force --profile default
BRANCH=`git rev-parse --abbrev-ref HEAD`
cd
cd desktop
git clone git@github.com:StashInvest/data-mart.git
cd data-mart
git checkout prod
git checkout $BRANCH
git rebase prod
cd ..
zip -qrX data-mart.zip data-mart
aws --profile default s3 cp data-mart.zip s3://stash-de-artifacts-prod/data_science/data-mart/latest/app.zip
rm data-mart.zip
rm -rf data-mart
mart
```

3. Deploy to Airflow Edge (for testing)
   1. Find your folder using `pwd`
   2. Replace `.` with your folder and run
      `scp -i ~/.ssh/edge_key_airflow.pem -r . ubuntu@172.20.12.67:/opt/stash/airflow/dags/`
1. Braze timestamp `timestamp 'epoch' + e.time * interval '1 second'`
2. All files with my commits `git log --no-merges --author="gatewaycat" --name-only --pretty=format:"" | sort -u`
3. LOOKER Moving average `mean(offset_list(${value},-10,10))`
   https://help.looker.com/hc/en-us/articles/360001285907-Calculating-Moving-Averages
1. LOOKER date with day of week
```
concat(
  substring(to_string(${payback_expected_contribution_new_subs_leading.new_subscriber_leading_subscribed_at_date}),6,5),
  " ",
  index(
    list("M","T","W","T","F","S","S"),
    mod(round(diff_days(
      date(1900,01,01),
      ${payback_expected_contribution_new_subs_leading.new_subscriber_leading_subscribed_at_date}
    ), 0), 7) + 1
  )
)
```
1. LOOKER custom dimension matches filter  
   ``matches_filter(${braze_events.occurred_hour_of_day},`14,15,16,17`)``

# Command Reference

1. **Show/hide hidden files** CMD + SHIFT + .

# Bash
1. `du -sh -- * | sort -h -r | head -n 10`
   `du -ah | sort -rh`
1. `java -jar briss-0.9.jar`
1. `zip -r -0 -e encrypted_file.zip /path/to/files`
1. `jupyter nbconvert --execute --clear-output <notebook>.ipynb`
1. `ls -d **/*`
1. `python <<< 'print(1/2)'`
1. ImageMagick
   `convert input.png -channel RGB -negate output.png`
   `convert input.png +dither -colors 16 output.png`
   `identify -verbose output.png`
   `convert output.png -fill "#FFFFFF" -opaque "#005E7A" output.png`
   `convert FILE.png -fuzz 4% -transparent "#ffffff" TRANSPARENT.png`
1. search current directory
   `grep -nr 'yourString*' .`
   1. `find . -name "*.lkml" -exec grep -H 'incremental_model' {} +`

# Looker
1. Moving average/Running average `mean(offset_list(${field_being_averaged},0,7))`

# Famous Schema Table Column values
```
source_braze.events.event

users.behaviors.app.FirstSession
users.behaviors.app.SessionEnd
users.behaviors.app.SessionStart
users.behaviors.CustomEvent
users.behaviors.Location
users.behaviors.Uninstall
users.campaigns.Conversion
users.campaigns.EnrollInControl
users.canvas.Conversion
users.canvas.Entry
users.messages.contentcard.Click
users.messages.contentcard.Impression
users.messages.contentcard.Send
users.messages.email.Bounce
users.messages.email.Click
users.messages.email.Delivery
users.messages.email.MarkAsSpam
users.messages.email.Open
users.messages.email.Send
users.messages.email.SoftBounce
users.messages.email.Unsubscribe
users.messages.inappmessage.Click
users.messages.inappmessage.Impression
users.messages.pushnotification.Bounce
users.messages.pushnotification.IosForeground
users.messages.pushnotification.Open
users.messages.pushnotification.Send
users.messages.webhook.Send


mart.messaging_events.event_name

email_bounce
email_clicked
email_opened
email_sent
email_softbounce
email_spam
email_undeliverable
email_unsubscribed
inapp_clicked
inapp_impression
push_bounce
push_opened
push_sent
sms_click
sms_sent
```


Redshift SQL generate date spine (spark SQL doesn't have generate_series, but you can use dbt_utils)  
```
SELECT '2022-01-01' + n AS event_date
FROM generate_series(0, 99, 1) AS n

SELECT generate_series(0,5) + '2022-01-01' AS event_date
```

Spark SQL  
```
select explode(sequence(date '2022-01-01', date '2022-02-01')) as event_date
```
