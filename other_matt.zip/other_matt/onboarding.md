# DSA Onboarding

1. Turn on
2. Allow the stash update thing. Wait an hour.
3. Mac settings
   1. Add fingerprint
   2. Settings -> Dock & Menu Bar -> Battery -> Show Percentage
   3. Finder -> View -> Show path bar
   4. On startup: Dropbox iTerm Pritunl Amethyst
   5. Hot corner bottom left = start screen saver 
   6. Display the time with seconds
   7. Show bluetooth in menubar
5. Open chrome. Sign into work google account, activate chrome sync. Sign into Okta.
   1. Extensions: [Wide GitHub](https://chrome.google.com/webstore/detail/wide-github/kaalofacklcidaampbokdplbklpeldpj/related?hl=en), ScrollMaps, New Tab Redirect, Clockwise, Print Friendly & PDF, Glean, Okta,  Browser Plugin, [GitHub icons](https://chrome.google.com/webstore/detail/file-icons-for-github-and/ficfmibkjjnpogdcfhfokmihanoldbfe) 
7. Sublime Text https://www.sublimetext.com/3
8. Anaconda.com
9. [Terminal setup](https://medium.com/ayuth/iterm2-zsh-oh-my-zsh-the-most-power-full-of-terminal-on-macos-bdb2823fb04c)
   1. iTerm2.com and also set to open as drop down from top (command backtick) by prefs -> profiles -> window -> full height left of screen; screen with cursor; all spaces; use transparency. and also open on startup/login, 
   2. Homebrew `/usr/bin/ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"`  
      `echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> /Users/sunderland/.zprofile`
      `eval "$(/opt/homebrew/bin/brew shellenv)"`
   4. `brew install zsh`
   5. Oh-my-zsh `sh -c "$(curl -fsSL https://raw.githubusercontent.com/robbyrussell/oh-my-zsh/master/tools/install.sh)"`
   6. [Powerlevel10k](https://dev.to/abdfnx/oh-my-zsh-powerlevel10k-cool-terminal-1no0)
      `git clone https://github.com/romkatv/powerlevel10k.git $ZSH_CUSTOM/themes/powerlevel10k`  
      `~/.zshrc` <- `ZSH_THEME="powerlevel10k/powerlevel10k"`  
      and `plugins=(git vscode macos)` (should be already there)  
      `p10k configure`
      1. Download https://code.visualstudio.com/Download
1. dropbox.com and mkdir dropbox/stash22/workspace/ and set it to only pull dropbox/stash22
2. Set up git
   1. or maybe try instead just  
      `brew tap microsoft/git`  
      `brew install --cask git-credential-manager-core`  
      or use the [package installer](https://github.com/GitCredentialManager/git-credential-manager/releases/latest)
   1. `git clone https://github.com/StashInvest/data-mart.git`
      and you will be prompted to log in.
   1. more steps are needed to push, I believe? NOPE. that's it!
   3. `git config --global pull.rebase false`
   4. `git config --global...` yes, you do actually have to set name and email event with the gcm
   5. connect pagerduty to slack.  
      okta -> pagerduty -> integrations -> slack.  
      slack -> #airflow services prod -> click acknoledge on any ticket -> click the little alert to sign into pager duty -> log in sso -> domain = stashinvest
1. [Workaround to get datamart dev to work on M1](https://stackoverflow.com/questions/70315418/installing-python3-7-macbook-air-m1-problem) (this might actually be unnecessary, see NEXT STEP)
   1. `arch -x86_64 /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install.sh)"`  
      `alias ibrew="arch -x86_64 /usr/local/bin/brew"`  
      `ibrew install python@3.7`
1. `pip install awscli --upgrade` to get the `emra` alias down there working. also copy over the `~/.ssh/` pem files and the `~/.aws/credentials` file (and add the file to the dock for easy access to copy in AWS-SSO creds every day)
2. `brew install --cask amethyst`

Just ignore?
```
❯ make ready
brew list python@3.7 || brew install python@3.7;
Error: No such keg: /opt/homebrew/Cellar/python@3.7
python@3.7: The x86_64 architecture is required for this software.
Error: python@3.7: An unsatisfied requirement failed this build.
make: *** [ready] Error 1
```

These did not seem to help
`echo 'export PATH="/usr/local/opt/python@3.7/bin:$PATH"' >> ~/.zshrc`  
`export LDFLAGS="-L/usr/local/opt/python@3.7/lib"`


1. Add `source ~/.bash_profile` to the end of `~/.zshrc` (because anaconda installer adds the necessary code to bash_profile, and you need to tell zshrc to run that stuff on startup)
2. setup pritunl https://stashinvest.atlassian.net/wiki/spaces/DSO/pages/571375656/Pritunl+VPN+Setup+AWS+Heroku+Access



Aliases to add to ~/.zshrc
```
source ~/.bash_profile
export PATH="/usr/local/opt/python@3.7/bin:$PATH"

alias zshrc="open ~/.zshrc"

alias workspace="  cd ~/dropbox/stash22/workspace; clear; ls"
alias mart="       cd ~/dropbox/stash22/workspace/data-mart; clear; ls"
alias attribution='cd ~/dropbox/stash22/workspace/stash-analytics/airflow_jobs/user_attribution_v2; clear; ls'
alias sandbox="    cd ~/dropbox/stash22/workspace/data-science-sandbox/other_matt; clear; ls"

alias gitlog="git log --graph --format='%C(auto) %h %d %s %Cblue %ai'"

EMR_KEY=~/.ssh/prod_ds_explore.pem

alias emra='export EMR_HOST=$(aws emr describe-cluster --cluster-id $(aws emr list-clusters --active --query '\''Clusters[?Name==`ds_experimental_emr_analytics`].Id'\'' --output text) | python3 -c "import sys, json; print(json.load(sys.stdin)['\''Cluster'\'']['\''MasterPublicDnsName'\''])")'

alias emrm='export EMR_HOST=$(aws emr describe-cluster --cluster-id $(aws emr list-clusters --active --query '\''Clusters[?Name==`ds_experimental_emr_modeling`].Id'\'' --output text) | python3 -c "import sys, json; print(json.load(sys.stdin)['\''Cluster'\'']['\''MasterPublicDnsName'\''])")'

alias deploy_mart='BRANCH=`git rev-parse --abbrev-ref HEAD`; cd
cd desktop; git clone git@github.com:StashInvest/data-mart.git; cd data-mart; git checkout prod; git checkout $BRANCH; git rebase prod; cd ..; zip -qrX data-mart.zip data-mart; aws --profile default s3 cp data-mart.zip s3://stash-de-artifacts-prod/data_science/data-mart/latest/app.zip; rm data-mart.zip; rm -rf data-mart; mart'

alias trigger_mart='echo '\''{'\"'run_add_on'\"' : '\"'--models my_model_name'\"', '\"'test_add_on'\"' : '\"'--models my_model_name'\"'}'\'
```


`conda install -c conda-forge nodejs`  
`jupyter labextension install @wallneradam/trailing_space_remover`
